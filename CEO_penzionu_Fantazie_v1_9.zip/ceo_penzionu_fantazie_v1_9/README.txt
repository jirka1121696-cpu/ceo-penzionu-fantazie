CEO penzionu Fantazie — bezplatná webová aplikace
Verze 1.9 — oprava inicializace aplikace, otestovaná základní interakce strategické portfolio, finanční kapacita a porovnání iniciativ
===================================================

Co je v balíčku
- index.html: responzivní aplikace pro mobil i počítač
- manifest.webmanifest a service-worker.js: základ pro instalaci jako webovou aplikaci (PWA) a offline načtení po první návštěvě
- Investiční komise: návrhy kampaní a investic se vstupy nákladů, očekávaných rezervací, příspěvku na rezervaci a jistoty; CFO vypočítá scénář včetně rizikově upraveného výsledku, CCO kontroluje obchodní zdůvodnění a CEO zaznamená schválení testu, vrácení k dopracování nebo zamítnutí; export návrhů do CSV. Jde o model podle zadaných předpokladů, ne garanci návratnosti.
- Vedení a týmy: organizační struktura CEO → CFO a CCO → specializované týmy; řízení strategických cílů a KPI s odpovědným vlastníkem, výchozí/cílovou/aktuální hodnotou, termínem, výpočtem postupu, upozorněním na zpoždění a exportem cílů do CSV; analytické reporty CFO, CCO a společný report CEO; převod doporučení do fronty úkolů s odpovědným týmem a stavem dokončení; ručně zadávané výsledky a rozhodovací deník
- Finance: orientační provozní model a cenové scénáře
- Strategie a rozpočet: portfolio příležitostí, kalkulace jednorázových i průběžných nákladů, rizikově upravený čistý příspěvek, orientační bod návratnosti, schvalování testů a kontrola schváleného rozpočtu proti limitu; CSV export. Výpočty vycházejí z ručně zadaných předpokladů.
- Měsíční plán vs. skutečnost: evidence plánovaných a skutečných tržeb, nákladů a obsazenosti; souhrn odchylek, úprava záznamů a CSV export; CFO report upozorní na zápornou odchylku posledního evidovaného měsíce
- Konkurence: ruční evidence veřejně ověřených informací a odkazy na průzkum
- Obchod a marketing: nápady pro Fantazáka, testy kampaní a záznam výsledků
- Akční plán: checklist, priority, export a obnovení JSON zálohy, export konkurence do CSV a tisk přehledu

Jak spustit
1. Rozbal ZIP.
2. Otevři index.html v prohlížeči.
3. Data se ukládají lokálně v daném prohlížeči.

Jak zdarma zveřejnit na webu
1. Vytvoř si účet na GitHubu.
2. Založ veřejný repozitář (např. ceo-penzionu-fantazie).
3. Nahraj index.html do kořene repozitáře.
4. V Settings → Pages vyber deploy z větve main a složky /(root).
5. Po zveřejnění dostaneš veřejnou adresu ve tvaru https://UZIVATEL.github.io/ceo-penzionu-fantazie/

Důležité limity verze 1.9
- Reporty CFO, CCO a CEO generují specializované analytické moduly podle pravidel a zadaných dat. Nejde o skutečný velký jazykový model ani autonomní tým AI agentů; role samy nepracují na pozadí a specialisté nejsou napojení na externí systémy.
- Nemá placené AI API, takže nevznikají poplatky za tokeny. Sama neumí automaticky číst internet, průběžně sledovat konkurenci, posílat hostům zprávy ani měnit rezervace či ceny.
- Průzkum konkurence se otevírá přes veřejné vyhledávání; informace je nutné ověřit a uložit ručně.
- Data zůstávají v konkrétním prohlížeči a nesynchronizují se mezi zařízeními. Použij Export JSON pro zálohu.
- Výpočty jsou orientační; ověř účetní čísla, provize, sezónnost a daně.

Instalace na mobilu: po zveřejnění otevři web v Chrome, menu ⋮ a zvol „Instalovat aplikaci“ nebo „Přidat na plochu“ (položka se liší podle prohlížeče). PWA vyžaduje HTTPS; lokální otevření souboru samo o sobě instalaci nezapne.


Ověření verze 1.9
- Opravena chyba při spuštění: aplikace se pokoušela vykreslit odstraněný týdenní checklist a tím přerušila inicializaci.
- Proveden automatický test v Chromium: načtení aplikace, navigace, reporty vedení, převod doporučení na úkoly, strategická příležitost a schválení, finanční přepočet, evidence konkurenta, uložení dat a mobilní šířka.
